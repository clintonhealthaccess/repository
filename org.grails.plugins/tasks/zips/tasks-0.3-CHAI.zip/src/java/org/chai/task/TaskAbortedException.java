package org.chai.task;

public class TaskAbortedException extends RuntimeException {

}
